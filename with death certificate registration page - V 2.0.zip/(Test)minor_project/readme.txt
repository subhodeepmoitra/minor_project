Contains the page for death certificate register.

The death certificate register page has only been added in the repository, 
but not has been integrated into the application.

The death certificate register portal had not been connected to any database,
it has not been integrated with the controller in the NodeJS file.
