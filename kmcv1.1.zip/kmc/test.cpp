#include<stdio.h>
int main(){
    int x=0;
    if(x++ > 0){
        printf("True");
    }
    else{
        printf("False")
    }
}